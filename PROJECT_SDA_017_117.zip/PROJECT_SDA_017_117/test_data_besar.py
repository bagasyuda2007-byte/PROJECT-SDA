import time
import random


# AVL TREE

class Node:
    def __init__(self, server):
        self.server = server
        self.left = None
        self.right = None
        self.height = 1


class AVLTree:

    def height(self, node):
        return node.height if node else 0

    def get_balance(self, node):
        if not node:
            return 0
        return self.height(node.left) - self.height(node.right)

    def right_rotate(self, y):

        if y is None or y.left is None:
            return y

        x = y.left
        t2 = x.right

        x.right = y
        y.left = t2

        y.height = max(
            self.height(y.left),
            self.height(y.right)
        ) + 1

        x.height = max(
            self.height(x.left),
            self.height(x.right)
        ) + 1

        return x

    def left_rotate(self, x):   

        if x is None or x.right is None:
            return x

        y = x.right
        t2 = y.left

        y.left = x
        x.right = t2

        x.height = max(
            self.height(x.left),
            self.height(x.right)
        ) + 1

        y.height = max(
            self.height(y.left),
            self.height(y.right)
        ) + 1

        return y

    def insert(self, root, server):

        if not root:
            return Node(server)

        # Key unik untuk perbandingan
        new_key = (
            server["cpu"],
            server["ram"],
            server["id"]
        )

        root_key = (
            root.server["cpu"],
            root.server["ram"],
            root.server["id"]
        )

        # BST Insert
        if new_key < root_key:
            root.left = self.insert(root.left, server)
        else:
            root.right = self.insert(root.right, server)

        # Update height
        root.height = 1 + max(
            self.height(root.left),
            self.height(root.right)
        )

        # Balance factor
        balance = self.get_balance(root)

       
        # LL CASE
        
        if balance > 1:

            left_key = (
                root.left.server["cpu"],
                root.left.server["ram"],
                root.left.server["id"]
            )

            if new_key < left_key:
                return self.right_rotate(root)

        
        # RR CASE
       
        if balance < -1:

            right_key = (
                root.right.server["cpu"],
                root.right.server["ram"],
                root.right.server["id"]
            )

            if new_key > right_key:
                return self.left_rotate(root)

        
        # LR CASE
        
        if balance > 1:

            left_key = (
                root.left.server["cpu"],
                root.left.server["ram"],
                root.left.server["id"]
            )

            if new_key > left_key:
                root.left = self.left_rotate(root.left)
                return self.right_rotate(root)

        
        # RL CASE
       
        if balance < -1:

            right_key = (
                root.right.server["cpu"],
                root.right.server["ram"],
                root.right.server["id"]
            )

            if new_key < right_key:
                root.right = self.right_rotate(root.right)
                return self.left_rotate(root)

        return root
    
    def get_min_value_node(self, node):

        current = node

        while current.left:
            current = current.left

        return current
    
    def delete(self, root, server):

        if not root:
            return root

        delete_key = (
            server["cpu"],
            server["ram"],
            server["id"]
        )

        root_key = (
            root.server["cpu"],
            root.server["ram"],
            root.server["id"]
        )

        # BST Delete
        if delete_key < root_key:

            root.left = self.delete(root.left, server)

        elif delete_key > root_key:

            root.right = self.delete(root.right, server)

        else:

            # node dengan 0 / 1 child
            if root.left is None:
                return root.right

            elif root.right is None:
                return root.left

            # node dengan 2 child
            temp = self.get_min_value_node(root.right)

            root.server = temp.server

            root.right = self.delete(
                root.right,
                temp.server
            )

        if root is None:
            return root

        # update height
        root.height = 1 + max(
            self.height(root.left),
            self.height(root.right)
        )

        balance = self.get_balance(root)

        # LL
        if (
            balance > 1
            and self.get_balance(root.left) >= 0
        ):
            return self.right_rotate(root)

        # LR
        if (
            balance > 1
            and self.get_balance(root.left) < 0
        ):
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)

        # RR
        if (
            balance < -1
            and self.get_balance(root.right) <= 0
        ):
            return self.left_rotate(root)

        # RL
        if (
            balance < -1
            and self.get_balance(root.right) > 0
        ):
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)

        return root

    def best_fit(self, root, vm):

        self.best = None

        def dfs(node):

            if not node:
                return

            pm = node.server

            if (
                pm["cpu"] >= vm["cpu"]
                and pm["ram"] >= vm["ram"]
            ):

                if self.best is None:

                    self.best = pm

                else:

                    current_waste = (
                        self.best["cpu"] - vm["cpu"]
                    ) + (
                        self.best["ram"] - vm["ram"]
                    )

                    new_waste = (
                        pm["cpu"] - vm["cpu"]
                    ) + (
                        pm["ram"] - vm["ram"]
                    )

                    if new_waste < current_waste:
                        self.best = pm

            dfs(node.left)
            dfs(node.right)

        dfs(root)

        return self.best


# GENERATE RANDOM DATA

CPU_OPTIONS_PM = [8, 12, 16, 24, 32, 48, 64]
RAM_OPTIONS_PM = [32, 64, 128, 256, 512]

CPU_OPTIONS_VM = [1, 2, 4, 6, 8, 12, 16]
RAM_OPTIONS_VM = [2, 4, 8, 16, 32, 64]

NUM_PM = 5000
NUM_VM = 10000

# Generate Physical Machines
physical_machines = []

for i in range(NUM_PM):
    physical_machines.append({
        "id": f"PM{i+1}",
        "cpu": random.choice(CPU_OPTIONS_PM),
        "ram": random.choice(RAM_OPTIONS_PM)
    })

# Generate Virtual Machines
virtual_machines = []

for i in range(NUM_VM):
    virtual_machines.append({
        "id": f"VM{i+1}",
        "cpu": random.choice(CPU_OPTIONS_VM),
        "ram": random.choice(RAM_OPTIONS_VM)
    })


# BUILD AVL TREE

tree = AVLTree()
root = None

print("Membangun AVL Tree...")

for pm in physical_machines:
    root = tree.insert(root, pm)

print("AVL Tree selesai dibuat.\n")


# VM PLACEMENT

placed = 0
failed = 0

start_time = time.perf_counter()

for vm in virtual_machines:

    server = tree.best_fit(root, vm)

    if server:

    # hapus PM lama dari AVL
        root = tree.delete(root, server)

        # update resource
        server["cpu"] -= vm["cpu"]
        server["ram"] -= vm["ram"]

        # insert kembali dengan resource baru
        root = tree.insert(root, server)

        placed += 1
    else:
        failed += 1

end_time = time.perf_counter()

execution_time = end_time - start_time

# HASIL

print("===== HASIL SIMULASI =====")
print(f"Jumlah PM       : {NUM_PM}")
print(f"Jumlah VM       : {NUM_VM}")
print(f"VM Ditempatkan  : {placed}")
print(f"VM Gagal        : {failed}")
print(f"Waktu Eksekusi  : {execution_time:.6f} detik")