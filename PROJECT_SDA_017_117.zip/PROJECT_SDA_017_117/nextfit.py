import time
import random

# KONFIGURASI DATASET RANDOM

CPU_OPTIONS_PM = [8, 12, 16, 24, 32, 48, 64]
RAM_OPTIONS_PM = [32, 64, 128, 256, 512]

CPU_OPTIONS_VM = [1, 2, 4, 6, 8, 12, 16]
RAM_OPTIONS_VM = [2, 4, 8, 16, 32, 64]

NUM_PM = 5000
NUM_VM = 10000

# GENERATE PHYSICAL MACHINES

physical_machines = []

for i in range(NUM_PM):
    physical_machines.append({
        "id": f"PM{i+1}",
        "cpu": random.choice(CPU_OPTIONS_PM),
        "ram": random.choice(RAM_OPTIONS_PM)
    })

# GENERATE VIRTUAL MACHINES

virtual_machines = []

for i in range(NUM_VM):
    virtual_machines.append({
        "id": f"VM{i+1}",
        "cpu": random.choice(CPU_OPTIONS_VM),
        "ram": random.choice(RAM_OPTIONS_VM)
    })


# NEXT FIT VM PLACEMENT

placed = 0       # menghitung jumlah VM yang berhasil ditempatkan
failed = 0       # menghitung jumlah VM yang gagal ditempatkan karena tidak ada PM yang memenuhi

current_index = 0          # menyimpan indeks PM terakhir yang berhasil menampung VM; pencarian VM berikutnya dimulai dari sini
num_pm = len(physical_machines)    # menyimpan total jumlah PM agar bisa digunakan sebagai batas perulangan dan modulo

start_time = time.perf_counter()   # mencatat waktu mulai eksekusi untuk mengukur performa algoritma

for vm in virtual_machines:        # iterasi setiap VM yang perlu ditempatkan ke salah satu PM

    found = False      # flag penanda apakah VM berhasil ditempatkan pada iterasi ini
    checked = 0        # menghitung berapa banyak PM yang sudah diperiksa agar tidak melebihi total PM (mencegah infinite loop)

    while checked < num_pm:    # terus cek PM selanjutnya selama belum semua PM diperiksa

        pm = physical_machines[current_index]    # ambil PM pada posisi current_index sebagai kandidat penempatan

        # Cek apakah PM cukup menampung VM
        if pm["cpu"] >= vm["cpu"] and pm["ram"] >= vm["ram"]:    # periksa apakah resource CPU dan RAM PM mencukupi kebutuhan VM

            # Alokasikan resource
            pm["cpu"] -= vm["cpu"]     # kurangi sisa CPU PM sebesar kebutuhan CPU VM
            pm["ram"] -= vm["ram"]     # kurangi sisa RAM PM sebesar kebutuhan RAM VM

            placed += 1    # tambah counter VM yang berhasil ditempatkan
            found = True   # tandai bahwa VM ini sudah berhasil ditempatkan

            # Next Fit:
            # VM berikutnya mulai mencari dari PM terakhir ini
            break          # hentikan pencarian dan lanjut ke VM berikutnya; current_index tidak direset (inilah inti algoritma Next Fit)

        current_index = (current_index + 1) % num_pm    # geser ke PM berikutnya secara melingkar (circular) menggunakan modulo
        checked += 1                                     # tambah counter PM yang sudah diperiksa

    if not found:      # jika setelah semua PM diperiksa tidak ada yang cocok
        failed += 1    # tambah counter VM yang gagal ditempatkan

end_time = time.perf_counter()    # mencatat waktu selesai eksekusi

# HASIL

print("\n===== NEXT FIT VM PLACEMENT =====")
print(f"Jumlah Physical Machine : {NUM_PM}")
print(f"Jumlah Virtual Machine  : {NUM_VM}")
print(f"VM berhasil ditempatkan : {placed}")
print(f"VM gagal ditempatkan    : {failed}")
print(f"Waktu eksekusi          : {end_time - start_time:.6f} detik")

# Menampilkan contoh 10 PM pertama setelah alokasi
print("\n===== SAMPLE KONDISI PM =====")

for pm in physical_machines[:10]:    # ambil 10 PM pertama sebagai sampel untuk melihat sisa resource setelah proses penempatan selesai
    print(
        f"{pm['id']} | "
        f"CPU Tersisa={pm['cpu']} | "
        f"RAM Tersisa={pm['ram']}"
    )